int ww(int, char *, int);
int ww_dir(int, char *);
int ww_cmd(int);
